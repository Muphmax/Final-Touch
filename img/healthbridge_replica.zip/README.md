# HealthBridge Frontend - Pixel Perfect Replica

This is a complete pixel-perfect HTML/CSS/JavaScript replica of the HealthBridge healthcare platform design system.

## Pages Included

1. **index.html** - Landing Page
   - Hero section with call-to-action
   - Features overview
   - Patient testimonials
   - Footer with links

2. **login.html** - Login Page
   - Email/password login form
   - "Remember me" checkbox
   - Password recovery link
   - Sign up redirect

3. **signup.html** - Sign Up Page
   - Multi-field registration form
   - Phone number with country code selector
   - Role selection (Patient, Facility, Caregiver)
   - Password visibility toggle
   - Terms agreement checkbox

4. **patient-dashboard.html** - Patient Dashboard
   - Sidebar navigation
   - Header with search and notifications
   - Health metrics cards
   - Upcoming appointments
   - Medical records section
   - Responsive grid layout

5. **doctor-profile.html** - Doctor Profile
   - Sidebar navigation
   - Doctor information card
   - Calendar widget
   - Patient data table
   - Conditions treated section
   - Responsive layout

6. **facility-page.html** - Facility Page
   - Hero section
   - Facility information card with rating
   - Services offered section
   - Operating hours
   - Contact information
   - Book appointment button

7. **find-healthcare-facility.html** - Find Healthcare Facilities
   - Search form with location
   - Popular categories grid
   - Featured facilities grid
   - Facility cards with ratings and tags
   - Responsive card layout

8. **facility-registration.html** - Facility Registration
   - Multi-step form (3 steps)
   - Progress indicator
   - Step 1: Basic Information
   - Step 2: Services
   - Step 3: Contact Information
   - Form validation

## Design Features

### Responsive Breakpoints
- 1440px - Desktop
- 1200px - Large tablet
- 1024px - Tablet
- 768px - Small tablet
- 480px - Mobile
- 360px - Small mobile

### Animations
- Page load: Fade in + slide up (opacity 0→1, y 20→0)
- Card hover: Scale 1.02
- Button hover: Scale 1.03
- Button tap: Scale 0.97
- Smooth transitions on all interactive elements

### Color Scheme
- Primary Blue: #0056D2
- Background White: #FFFFFF
- Background Light: #F8F9FA
- Text Dark: #1A1A1A
- Text Muted: #666666
- Border Color: #E0E0E0
- Success: #28A745
- Warning: #FF8800
- Danger: #DC3545

### Typography
- Font Family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif
- Font Weights: 400, 500, 600, 700
- Responsive font sizes across all breakpoints

## Technology Stack

- **HTML5** - Semantic markup
- **CSS3** - Internal styles with CSS variables
- **Vanilla JavaScript** - No frameworks
- **Framer Motion** - Smooth animations (via CSS animations)

## Features

✅ Pixel-perfect design replication
✅ Fully responsive (mobile-first approach)
✅ No horizontal scrolling on any device
✅ No hidden content on mobile
✅ Smooth animations and transitions
✅ Interactive form elements
✅ Navigation between pages
✅ Accessible markup
✅ Cross-browser compatible
✅ Performance optimized

## How to Use

1. Open any HTML file in a modern web browser
2. All pages are standalone and can be opened directly
3. Use browser developer tools to test responsiveness
4. Resize browser window to test different breakpoints

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Notes

- All CSS is internal (no external stylesheets)
- All JavaScript is vanilla (no frameworks or libraries)
- Images are represented as placeholder divs with background colors
- All animations use CSS keyframes
- Form submissions are handled with console logging for demonstration

---

Created: June 23, 2026
Design System: HealthBridge One ID Platform
